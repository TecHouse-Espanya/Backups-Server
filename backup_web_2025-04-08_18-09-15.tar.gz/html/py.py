
def es_bisiesto(year):
    if year%4 != 0:
        return False
    elif year%100 !=0:
        return True
    elif year%400 !=0:
        return False
    else:
        return True

def main():
    while True:
        try:
            year = int(input("Ingresa (0 salir):"))
            if year == 0:
                break
            if year < 1582:
                print("No es gregoriano")
            elif es_bisiesto(year):
                print("Año bisiest")
            else:
                print("Año comun")
                
        except ValueError:
            print("Error, ingresa un numero")
            
        
if __name__ == "__main__":
    main()